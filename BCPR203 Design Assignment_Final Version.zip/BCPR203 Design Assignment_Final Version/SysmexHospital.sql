-- delete database if exists 
DROP DATABASE IF EXISTS hospital; 

-- create and use the database 
CREATE DATABASE hospital; 

USE hospital; 

-- *******************************************************************************************************************************
-- Creating Tables ReferType,Referee,Patient,Department,Surgeon and Referral

CREATE TABLE ReferType (
    typeId INT NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (typeId),
    typeName VARCHAR(15)
)  ENGINE=INNODB;


-- Create table Referee
CREATE TABLE Referee (
    refereeId INT NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (refereeId),
    refFname VARCHAR(20),
    refLname VARCHAR(20),
    typeId INT,
    FOREIGN KEY (typeId)
        REFERENCES ReferType (typeId)
)  ENGINE=INNODB;


-- Create table Patient
CREATE TABLE Patient (
    patientId INT NOT NULL AUTO_INCREMENT,
    nhi CHAR(7),
    patientFname VARCHAR(20),
    patientLname VARCHAR(20),
    dob DATE,
    gender VARCHAR(6),
    hte VARCHAR(3),
    PRIMARY KEY (patientId)
)  ENGINE=INNODB;


-- Create table Department
CREATE TABLE Department (
    depId INT NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (depId),
    depName VARCHAR(20)
)  ENGINE=INNODB;
 

-- Create table Surgeon
CREATE TABLE Surgeon (
    surgeonId INT NOT NULL AUTO_INCREMENT,
    sFname VARCHAR(20),
    sLname VARCHAR(20),
    PRIMARY KEY (surgeonId),
    depId INT,
    FOREIGN KEY (depId)
        REFERENCES Department (depId)
)  ENGINE=INNODB;
 

-- Create table Referral
CREATE TABLE Referral (
    refId INT NOT NULL AUTO_INCREMENT,
    refDate DATE,
    waitList DATE,
    fsa DATE,
    PRIMARY KEY (refId),
    patientId INT,
    surgeonId INT,
    refereeId INT,
    FOREIGN KEY (patientId)
        REFERENCES Patient (patientId),
    FOREIGN KEY (surgeonId)
        REFERENCES Surgeon (surgeonId),
    FOREIGN KEY (refereeId)
        REFERENCES Referee (refereeId)
)  ENGINE=INNODB;



-- *******************************************************************************************************************************
-- Loading Tables ReferType,Referee,Patient,Department,Surgeon and Referral
-- Six csv files are available in the csv folder

-- Load table ReferFrom
load data local infile 'H:\\Refertype.csv'
into table ReferType
lines terminated by '\n'
(typeName);

-- Load table Referee
load data local infile 'H:\\Referee.csv'
into table Referee
fields terminated by ','
lines terminated by '\n'
(refFname,refLname,typeId);


 -- Load table Patient
load data local infile 'H:\\Patient.csv'
into table Patient
fields terminated by ','
lines terminated by '\n'
(nhi,patientFname,patientLname,dob,gender,hte);


  -- Load table Department
load data local infile 'H:\\Department.csv'
into table Department
fields terminated by ','
lines terminated by '\n'
(depName);


-- Load table Surgeon
load data local infile 'H:\\Surgeon.csv'
into table Surgeon
fields terminated by ','
lines terminated by '\n'
(sFname,sLname,depId);


-- Load table Referral
load data local infile 'H:\\Referral.csv'
into table Referral
fields terminated by ','
lines terminated by '\n'
(refDate,waitList,fsa,patientId,surgeonId,refereeId);

-- Update blank fsa field with current date
-- set sql_safe_updates = 0 is added to  1175 avoid safe update mode error
set sql_safe_updates = 0;
UPDATE Referral 
SET 
    fsa = NOW()
WHERE
    fsa LIKE '0000-00-00';

-- ******************************************************************************************************************************************************
-- Display the tables ReferType, Referee, Referral, Patient, Department and Surgeon

-- For table ReferType
SELECT 
    typeID AS 'Referral Type ID', typeName AS 'Referred From'
FROM
    ReferType;

-- For table Referee
SELECT 
    refereeId AS 'Referee ID',
    refFname AS 'Referee First Name',
    refLname AS 'Referee Last Name',
    typeID AS 'Referral Type ID'
FROM
    Referee;


-- Derive Waiting Days and display the table Referral
SELECT 
    refId AS 'Reference ID',
    refDate AS 'Referral Date',
    waitList AS 'Added to WaitList Date',
    fsa AS 'FSA Date',
    patientId AS 'Patient ID',
    surgeonId AS 'Surgeon ID',
    refereeId AS 'Referee ID',
    DATEDIFF(fsa, refDate) AS 'Waitingdays'
FROM
    Referral;


-- Derive Patient Age from Date of Birth and display the table Patient
SELECT 
    patientId AS 'Patient ID',
    SHA2('nhi', 256) AS 'Encrypted NHI',
    patientFname AS 'Patient First Name',
    patientLname AS 'Patient Last Name',
    dob AS 'DOB',
    gender AS 'Gender',
    hte AS 'HTE',
    FLOOR(DATEDIFF(SYSDATE(), dob) / 365.25) AS 'Patient Age'
FROM
    Patient;


-- For table Department
SELECT 
    depId AS 'Department ID', depName AS 'Department Name'
FROM
    Department;
    

-- For table Surgeon
SELECT 
    surgeonId AS 'Surgeon ID',
    sFname AS 'Surgeon First Name',
    sLname AS 'Surgeon Last Name',
    depID AS 'Department ID'
FROM
    Surgeon;

-- ******************************************************************************************************************************************************
-- Queries

-- Q1 How many people have been referred for surgery?
SELECT 
    COUNT(refId) 'Total number of Patients referred for Surgery'
FROM
    Referral;


-- Q2 What is the average time taken to see a Surgeon by Department?
SELECT 
    Department.depName AS 'Department Name',
    FLOOR(AVG(DATEDIFF(fsa, refDate))) AS 'Average Days taken to meet Surgeon'
FROM
    Referral
        INNER JOIN
    Surgeon ON Referral.surgeonId = Surgeon.surgeonId
        INNER JOIN
    Department ON Surgeon.depId = Department.depId
GROUP BY depName;


-- Q3 Who has each Surgeon had on their list and how long have they been waiting or did they wait?
SELECT 
    Surgeon.surgeonId AS 'Surgeon ID',
    CONCAT_WS(' ', sFname, sLname) AS 'Surgeon Nmae',
    CONCAT(patientFname, ' ', patientLname) AS 'Patient Name',
    DATEDIFF(fsa, refDate) AS 'Waiting Days',
    (CASE
        WHEN DATEDIFF(fsa, refDate) > 0 THEN 'Yes'
        ELSE 'No'
    END) AS 'Waiting Status'
FROM
    Patient
        JOIN
    Referral ON Patient.patientId = Referral.patientId
        JOIN
    Surgeon ON Referral.SurgeonId = Surgeon.surgeonId
ORDER BY Surgeon.surgeonId;

-- Q4 Assuming that all patients under 18 need to be seen by Paediatric Surgery, are there any patients who need to be reassigned? 
SELECT 
    Patient.patientId AS 'Pateint ID',
    CONCAT(patientFname, ' ', patientLname) AS 'Patient Name',
    depName AS 'Currently Assigned Department'
FROM
    Patient
        INNER JOIN
    Referral ON Patient.patientId = Referral.patientId
        INNER JOIN
    Surgeon ON Referral.SurgeonId = Surgeon.surgeonId
        INNER JOIN
    Department ON Surgeon.depId = Department.depId
WHERE
    (DATEDIFF(refDate, dob) / 365.25) < 18
        AND Surgeon.depId <> 5;


-- Q5 What percentage of patient were seen within the target of 80 days by department?
-- 1)
SELECT 
    s.dep AS 'Department Name',
    CONCAT(FLOOR((s.cnt / j.cnt) * 100), '%') AS 'Percentage'
FROM
    (SELECT 
        Department.depName AS dep, COUNT(refId) AS cnt
    FROM
        Referral
    INNER JOIN Surgeon ON Surgeon.surgeonId = Referral.surgeonId
        AND DATEDIFF(fsa, refDate) <= 80
    INNER JOIN Department ON Surgeon.depId = Department.depId
    GROUP BY Department.depId) s
        CROSS JOIN
    (SELECT 
        Department.depName, COUNT(refId) AS cnt
    FROM
        Referral
    INNER JOIN Surgeon ON Surgeon.surgeonId = Referral.surgeonId
    INNER JOIN Department ON Surgeon.depId = Department.depId
    GROUP BY Department.depId) j;

-- 2)
SELECT 
    depName,
    depId,
    (FLOOR(((SELECT 
                    COUNT(*)
                FROM
                    Referral
                        INNER JOIN
                    Patient ON Referral.patientId = Patient.patientId
                        INNER JOIN
                    Surgeon ON Referral.surgeonId = Surgeon.surgeonId
                WHERE
                    DATEDIFF(fsa, refDate) <= 80
                GROUP BY depName) / (SELECT 
                    COUNT(*)
                FROM
                    Referral
                        INNER JOIN
                    Patient ON Referral.patientId = Patient.patientId
                        INNER JOIN
                    Surgeon ON Referral.surgeonId = Surgeon.surgeonId
                WHERE
                    surgeon.depId = Department.depId
                        AND hte = 'Yes')) * 100)) AS Percentage
FROM
    Department;